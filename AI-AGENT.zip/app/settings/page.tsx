"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { User, Bell, Shield, Palette, CreditCard, Key, Globe, Moon, Sun, Check } from "lucide-react"
import { cn } from "@/lib/utils"

const settingsSections = [
  { id: "profile", name: "Profile", icon: User },
  { id: "notifications", name: "Notifications", icon: Bell },
  { id: "security", name: "Security", icon: Shield },
  { id: "appearance", name: "Appearance", icon: Palette },
  { id: "billing", name: "Billing", icon: CreditCard },
  { id: "api", name: "API Keys", icon: Key },
]

export default function SettingsPage() {
  const [activeSection, setActiveSection] = useState("profile")
  const [profile, setProfile] = useState({
    name: "Alex Johnson",
    email: "alex@company.com",
    company: "Acme Inc",
    role: "Marketing Manager",
  })
  const [notifications, setNotifications] = useState({
    emailCampaigns: true,
    emailReports: true,
    emailAlerts: false,
    pushCampaigns: true,
    pushReports: false,
    pushAlerts: true,
  })
  const [appearance, setAppearance] = useState({
    theme: "dark",
    language: "en",
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Background gradient effects */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute top-1/2 -left-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -bottom-40 right-1/3 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold">Settings</h1>
          <p className="text-muted-foreground mt-1">Manage your account and preferences</p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Settings Navigation */}
          <aside className="w-full lg:w-64 shrink-0">
            <nav className="p-4 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
              <div className="space-y-1">
                {settingsSections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={cn(
                      "flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-medium transition-colors",
                      activeSection === section.id
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                    )}
                  >
                    <section.icon className="h-4 w-4" />
                    {section.name}
                  </button>
                ))}
              </div>
            </nav>
          </aside>

          {/* Settings Content */}
          <div className="flex-1 space-y-6">
            {/* Profile Section */}
            {activeSection === "profile" && (
              <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                <h2 className="text-lg font-semibold mb-6">Profile Information</h2>
                <div className="flex flex-col sm:flex-row gap-6 mb-8">
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center text-3xl font-semibold text-primary">
                      {profile.name.split(" ").map((n) => n[0]).join("")}
                    </div>
                    <button className="text-sm text-primary hover:underline">Change photo</button>
                  </div>
                  <div className="flex-1 space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-muted-foreground mb-2">Full Name</label>
                        <input
                          type="text"
                          value={profile.name}
                          onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-muted-foreground mb-2">Email</label>
                        <input
                          type="email"
                          value={profile.email}
                          onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-muted-foreground mb-2">Company</label>
                        <input
                          type="text"
                          value={profile.company}
                          onChange={(e) => setProfile({ ...profile, company: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-muted-foreground mb-2">Role</label>
                        <input
                          type="text"
                          value={profile.role}
                          onChange={(e) => setProfile({ ...profile, role: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end">
                  <button className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">
                    Save Changes
                  </button>
                </div>
              </div>
            )}

            {/* Notifications Section */}
            {activeSection === "notifications" && (
              <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                <h2 className="text-lg font-semibold mb-6">Notification Preferences</h2>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium mb-4">Email Notifications</h3>
                    <div className="space-y-3">
                      {[
                        { key: "emailCampaigns", label: "Campaign updates", desc: "Get notified when campaigns start, end, or hit milestones" },
                        { key: "emailReports", label: "Weekly reports", desc: "Receive weekly performance summaries" },
                        { key: "emailAlerts", label: "Alert notifications", desc: "Get notified about issues or anomalies" },
                      ].map((item) => (
                        <div key={item.key} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                          <div>
                            <p className="font-medium">{item.label}</p>
                            <p className="text-sm text-muted-foreground">{item.desc}</p>
                          </div>
                          <button
                            onClick={() => setNotifications({ ...notifications, [item.key]: !notifications[item.key as keyof typeof notifications] })}
                            className={cn(
                              "w-12 h-6 rounded-full transition-colors relative",
                              notifications[item.key as keyof typeof notifications] ? "bg-primary" : "bg-secondary"
                            )}
                          >
                            <div className={cn(
                              "w-5 h-5 rounded-full bg-foreground absolute top-0.5 transition-transform",
                              notifications[item.key as keyof typeof notifications] ? "translate-x-6" : "translate-x-0.5"
                            )} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-4">Push Notifications</h3>
                    <div className="space-y-3">
                      {[
                        { key: "pushCampaigns", label: "Campaign updates", desc: "Get instant push notifications for campaigns" },
                        { key: "pushReports", label: "Report ready", desc: "Get notified when new reports are available" },
                        { key: "pushAlerts", label: "Critical alerts", desc: "Receive critical alerts immediately" },
                      ].map((item) => (
                        <div key={item.key} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                          <div>
                            <p className="font-medium">{item.label}</p>
                            <p className="text-sm text-muted-foreground">{item.desc}</p>
                          </div>
                          <button
                            onClick={() => setNotifications({ ...notifications, [item.key]: !notifications[item.key as keyof typeof notifications] })}
                            className={cn(
                              "w-12 h-6 rounded-full transition-colors relative",
                              notifications[item.key as keyof typeof notifications] ? "bg-primary" : "bg-secondary"
                            )}
                          >
                            <div className={cn(
                              "w-5 h-5 rounded-full bg-foreground absolute top-0.5 transition-transform",
                              notifications[item.key as keyof typeof notifications] ? "translate-x-6" : "translate-x-0.5"
                            )} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Security Section */}
            {activeSection === "security" && (
              <div className="space-y-6">
                <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                  <h2 className="text-lg font-semibold mb-6">Change Password</h2>
                  <div className="space-y-4 max-w-md">
                    <div>
                      <label className="block text-sm font-medium text-muted-foreground mb-2">Current Password</label>
                      <input
                        type="password"
                        placeholder="Enter current password"
                        className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted-foreground mb-2">New Password</label>
                      <input
                        type="password"
                        placeholder="Enter new password"
                        className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted-foreground mb-2">Confirm New Password</label>
                      <input
                        type="password"
                        placeholder="Confirm new password"
                        className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                    <button className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">
                      Update Password
                    </button>
                  </div>
                </div>
                <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                  <h2 className="text-lg font-semibold mb-4">Two-Factor Authentication</h2>
                  <p className="text-muted-foreground mb-4">Add an extra layer of security to your account</p>
                  <button className="px-6 py-2.5 bg-secondary text-foreground rounded-lg font-medium hover:bg-secondary/80 transition-colors">
                    Enable 2FA
                  </button>
                </div>
              </div>
            )}

            {/* Appearance Section */}
            {activeSection === "appearance" && (
              <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                <h2 className="text-lg font-semibold mb-6">Appearance Settings</h2>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium mb-4">Theme</h3>
                    <div className="grid grid-cols-3 gap-4">
                      {[
                        { id: "light", label: "Light", icon: Sun },
                        { id: "dark", label: "Dark", icon: Moon },
                        { id: "system", label: "System", icon: Globe },
                      ].map((theme) => (
                        <button
                          key={theme.id}
                          onClick={() => setAppearance({ ...appearance, theme: theme.id })}
                          className={cn(
                            "flex flex-col items-center gap-3 p-4 rounded-xl border transition-colors",
                            appearance.theme === theme.id
                              ? "border-primary bg-primary/10"
                              : "border-border/50 bg-secondary/30 hover:bg-secondary/50"
                          )}
                        >
                          <theme.icon className="h-6 w-6" />
                          <span className="text-sm font-medium">{theme.label}</span>
                          {appearance.theme === theme.id && (
                            <Check className="h-4 w-4 text-primary" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-4">Language</h3>
                    <select
                      value={appearance.language}
                      onChange={(e) => setAppearance({ ...appearance, language: e.target.value })}
                      className="w-full max-w-xs px-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="en">English</option>
                      <option value="es">Spanish</option>
                      <option value="fr">French</option>
                      <option value="de">German</option>
                      <option value="pt">Portuguese</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Billing Section */}
            {activeSection === "billing" && (
              <div className="space-y-6">
                <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-lg font-semibold">Current Plan</h2>
                      <p className="text-muted-foreground">You are currently on the Pro plan</p>
                    </div>
                    <span className="px-4 py-1.5 bg-primary/20 text-primary rounded-full text-sm font-medium">Pro</span>
                  </div>
                  <div className="grid sm:grid-cols-3 gap-4 mb-6">
                    <div className="p-4 rounded-lg bg-secondary/30">
                      <p className="text-2xl font-bold">$49</p>
                      <p className="text-sm text-muted-foreground">per month</p>
                    </div>
                    <div className="p-4 rounded-lg bg-secondary/30">
                      <p className="text-2xl font-bold">8,420</p>
                      <p className="text-sm text-muted-foreground">credits used</p>
                    </div>
                    <div className="p-4 rounded-lg bg-secondary/30">
                      <p className="text-2xl font-bold">1,580</p>
                      <p className="text-sm text-muted-foreground">credits remaining</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">
                      Upgrade Plan
                    </button>
                    <button className="px-6 py-2.5 bg-secondary text-foreground rounded-lg font-medium hover:bg-secondary/80 transition-colors">
                      View Usage
                    </button>
                  </div>
                </div>
                <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                  <h2 className="text-lg font-semibold mb-4">Payment Method</h2>
                  <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30">
                    <div className="w-12 h-8 rounded bg-gradient-to-r from-blue-600 to-blue-400 flex items-center justify-center text-white text-xs font-bold">
                      VISA
                    </div>
                    <div>
                      <p className="font-medium">•••• •••• •••• 4242</p>
                      <p className="text-sm text-muted-foreground">Expires 12/2028</p>
                    </div>
                    <button className="ml-auto text-sm text-primary hover:underline">Edit</button>
                  </div>
                </div>
              </div>
            )}

            {/* API Keys Section */}
            {activeSection === "api" && (
              <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-lg font-semibold">API Keys</h2>
                    <p className="text-muted-foreground">Manage your API keys for integrations</p>
                  </div>
                  <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors text-sm">
                    Generate New Key
                  </button>
                </div>
                <div className="space-y-3">
                  {[
                    { name: "Production Key", key: "mk_prod_xxxx...xxxx", created: "Mar 15, 2026", lastUsed: "2 hours ago" },
                    { name: "Development Key", key: "mk_dev_xxxx...xxxx", created: "Feb 20, 2026", lastUsed: "5 days ago" },
                  ].map((apiKey) => (
                    <div key={apiKey.name} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                      <div>
                        <p className="font-medium">{apiKey.name}</p>
                        <p className="text-sm font-mono text-muted-foreground">{apiKey.key}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Created {apiKey.created}</p>
                        <p className="text-sm text-muted-foreground">Last used {apiKey.lastUsed}</p>
                      </div>
                      <button className="ml-4 text-sm text-red-400 hover:underline">Revoke</button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
