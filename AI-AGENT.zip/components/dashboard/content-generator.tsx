"use client"

import { useState } from "react"
import { Sparkles, ChevronDown, RefreshCw, Copy, Check, Instagram, Mail, Megaphone, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

const platforms = [
  { name: "Instagram", icon: Instagram },
  { name: "Email", icon: Mail },
  { name: "Ads", icon: Megaphone },
  { name: "Blog", icon: FileText },
]

const tones = ["Professional", "Friendly", "Luxury", "Casual"]

interface ContentGeneratorProps {
  campaignIdea: string
  setCampaignIdea: React.Dispatch<React.SetStateAction<string>>
  selectedPlatform: string
  setSelectedPlatform: React.Dispatch<React.SetStateAction<string>>
  selectedTone: string
  setSelectedTone: React.Dispatch<React.SetStateAction<string>>
  generatedContent: Record<string, string>
  setGeneratedContent: React.Dispatch<React.SetStateAction<Record<string, string>>>
  isGenerating: boolean
  setIsGenerating: React.Dispatch<React.SetStateAction<boolean>>
}

export function ContentGenerator({
  campaignIdea,
  setCampaignIdea,
  selectedPlatform,
  setSelectedPlatform,
  selectedTone,
  setSelectedTone,
  generatedContent,
  setGeneratedContent,
  isGenerating,
  setIsGenerating,
}: ContentGeneratorProps) {
  const [platformDropdownOpen, setPlatformDropdownOpen] = useState(false)
  const [toneDropdownOpen, setToneDropdownOpen] = useState(false)
  const [copiedCard, setCopiedCard] = useState<string | null>(null)

  const handleGenerate = async () => {
    if (!campaignIdea.trim()) return
    
    setIsGenerating(true)
    
    // Simulate AI generation with delay
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    const mockContent: Record<string, string> = {
      Instagram: `✨ ${campaignIdea}\n\nReady to transform your ${selectedTone.toLowerCase()} approach? Our latest solution is here to revolutionize the way you connect with your audience.\n\n🔥 Key highlights:\n• Innovative features designed for you\n• Seamless integration with your workflow\n• Results that speak for themselves\n\nTap the link in bio to learn more! 👆\n\n#Marketing #Innovation #Growth #${campaignIdea.split(' ')[0]}`,
      
      Email: `Subject: Discover the Future of ${campaignIdea}\n\nHi there,\n\nWe hope this message finds you well. We&apos;re thrilled to share something exciting with you.\n\n${campaignIdea} - it&apos;s not just a concept, it&apos;s a game-changer. Here&apos;s why you&apos;ll love it:\n\n• Personalized experience tailored to your needs\n• Cutting-edge technology that works for you\n• A ${selectedTone.toLowerCase()} approach to solving real problems\n\nReady to take the next step? Click below to explore more.\n\n[Explore Now]\n\nBest regards,\nThe Team`,
      
      Ads: `🚀 ${campaignIdea}\n\nUnlock unprecedented growth with our ${selectedTone.toLowerCase()} solution.\n\n✅ Proven results\n✅ Easy implementation\n✅ 24/7 support\n\nLimited time offer - Start your free trial today!\n\n[Get Started Now]`,
      
      Blog: `# ${campaignIdea}: A Complete Guide\n\n## Introduction\n\nIn today&apos;s fast-paced digital landscape, ${campaignIdea.toLowerCase()} has become more important than ever. This comprehensive guide will walk you through everything you need to know.\n\n## Why It Matters\n\nWith a ${selectedTone.toLowerCase()} approach, businesses are seeing remarkable transformations in how they engage with their audience...\n\n## Key Takeaways\n\n1. Understanding the fundamentals\n2. Implementing best practices\n3. Measuring success\n\n## Conclusion\n\nThe future is here, and it&apos;s time to embrace it. Start your journey today.`,
    }
    
    setGeneratedContent(mockContent)
    setIsGenerating(false)
  }

  const handleRegenerate = async (platform: string) => {
    setIsGenerating(true)
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setGeneratedContent(prev => ({
      ...prev,
      [platform]: `[Regenerated] ${prev[platform]?.substring(0, 50)}... New creative variation for ${platform} with ${selectedTone.toLowerCase()} tone.`
    }))
    
    setIsGenerating(false)
  }

  const handleCopy = (platform: string, content: string) => {
    navigator.clipboard.writeText(content)
    setCopiedCard(platform)
    setTimeout(() => setCopiedCard(null), 2000)
  }

  const PlatformIcon = platforms.find(p => p.name === selectedPlatform)?.icon || Megaphone

  return (
    <div className="flex-1 space-y-6">
      {/* Input Section */}
      <div className="rounded-2xl border border-border/50 bg-card/60 backdrop-blur-xl p-6 space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Campaign Idea</label>
          <Textarea
            placeholder="Enter your campaign idea... e.g., Launch a new eco-friendly product line targeting millennials"
            value={campaignIdea}
            onChange={(e) => setCampaignIdea(e.target.value)}
            className="min-h-[120px] bg-secondary/50 border-border/50 focus:border-primary/50 resize-none transition-colors"
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          {/* Platform Selector */}
          <div className="flex-1 space-y-2">
            <label className="text-sm font-medium text-foreground">Platform</label>
            <div className="relative">
              <Button
                variant="outline"
                onClick={() => setPlatformDropdownOpen(!platformDropdownOpen)}
                className="w-full justify-between bg-secondary/50 border-border/50 hover:border-primary/50 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <PlatformIcon className="h-4 w-4" />
                  {selectedPlatform}
                </span>
                <ChevronDown className={cn("h-4 w-4 transition-transform", platformDropdownOpen && "rotate-180")} />
              </Button>
              {platformDropdownOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border/50 rounded-lg shadow-xl z-10 overflow-hidden">
                  {platforms.map((platform) => (
                    <button
                      key={platform.name}
                      onClick={() => {
                        setSelectedPlatform(platform.name)
                        setPlatformDropdownOpen(false)
                      }}
                      className={cn(
                        "w-full px-4 py-2.5 text-left text-sm transition-colors flex items-center gap-2",
                        selectedPlatform === platform.name
                          ? "bg-primary/10 text-primary"
                          : "hover:bg-secondary text-foreground"
                      )}
                    >
                      <platform.icon className="h-4 w-4" />
                      {platform.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Tone Selector */}
          <div className="flex-1 space-y-2">
            <label className="text-sm font-medium text-foreground">Tone</label>
            <div className="relative">
              <Button
                variant="outline"
                onClick={() => setToneDropdownOpen(!toneDropdownOpen)}
                className="w-full justify-between bg-secondary/50 border-border/50 hover:border-primary/50 transition-colors"
              >
                {selectedTone}
                <ChevronDown className={cn("h-4 w-4 transition-transform", toneDropdownOpen && "rotate-180")} />
              </Button>
              {toneDropdownOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border/50 rounded-lg shadow-xl z-10 overflow-hidden">
                  {tones.map((tone) => (
                    <button
                      key={tone}
                      onClick={() => {
                        setSelectedTone(tone)
                        setToneDropdownOpen(false)
                      }}
                      className={cn(
                        "w-full px-4 py-2.5 text-left text-sm transition-colors",
                        selectedTone === tone
                          ? "bg-primary/10 text-primary"
                          : "hover:bg-secondary text-foreground"
                      )}
                    >
                      {tone}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={isGenerating || !campaignIdea.trim()}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium h-12 transition-all duration-200"
        >
          {isGenerating ? (
            <span className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 animate-spin" />
              Generating...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Generate Content
            </span>
          )}
        </Button>
      </div>

      {/* Output Section */}
      {Object.keys(generatedContent).length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-foreground">Generated Content</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {platforms.map((platform) => {
              const content = generatedContent[platform.name]
              if (!content) return null
              
              return (
                <div
                  key={platform.name}
                  className="rounded-xl border border-border/50 bg-card/60 backdrop-blur-xl p-5 space-y-4 transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <platform.icon className="h-4 w-4 text-primary" />
                      </div>
                      <span className="font-medium text-foreground">{platform.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRegenerate(platform.name)}
                        disabled={isGenerating}
                        className="h-8 w-8 p-0 hover:bg-secondary"
                      >
                        <RefreshCw className={cn("h-4 w-4", isGenerating && "animate-spin")} />
                        <span className="sr-only">Regenerate</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(platform.name, content)}
                        className="h-8 w-8 p-0 hover:bg-secondary"
                      >
                        {copiedCard === platform.name ? (
                          <Check className="h-4 w-4 text-primary" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                        <span className="sr-only">Copy</span>
                      </Button>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto pr-2 scrollbar-thin">
                    {content}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
