"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Sidebar } from "@/components/dashboard/sidebar"
import { ContentGenerator } from "@/components/dashboard/content-generator"

export default function MarketingDashboard() {
  const [targetAudience, setTargetAudience] = useState({
    age: "",
    interests: "",
    region: "",
  })
  const [campaignGoal, setCampaignGoal] = useState("")
  const [campaignIdea, setCampaignIdea] = useState("")
  const [selectedPlatform, setSelectedPlatform] = useState("Instagram")
  const [selectedTone, setSelectedTone] = useState("Professional")
  const [generatedContent, setGeneratedContent] = useState<Record<string, string>>({})
  const [isGenerating, setIsGenerating] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Background gradient effects */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute top-1/2 -left-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -bottom-40 right-1/3 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          <Sidebar
            targetAudience={targetAudience}
            setTargetAudience={setTargetAudience}
            campaignGoal={campaignGoal}
            setCampaignGoal={setCampaignGoal}
          />
          <ContentGenerator
            campaignIdea={campaignIdea}
            setCampaignIdea={setCampaignIdea}
            selectedPlatform={selectedPlatform}
            setSelectedPlatform={setSelectedPlatform}
            selectedTone={selectedTone}
            setSelectedTone={setSelectedTone}
            generatedContent={generatedContent}
            setGeneratedContent={setGeneratedContent}
            isGenerating={isGenerating}
            setIsGenerating={setIsGenerating}
          />
        </div>
      </main>
    </div>
  )
}
