"use client"

import { useState } from "react"
import { Upload, Users, Target, FileText, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

const campaignGoals = ["Awareness", "Sales", "Engagement"]

interface SidebarProps {
  targetAudience: {
    age: string
    interests: string
    region: string
  }
  setTargetAudience: React.Dispatch<React.SetStateAction<{
    age: string
    interests: string
    region: string
  }>>
  campaignGoal: string
  setCampaignGoal: React.Dispatch<React.SetStateAction<string>>
}

export function Sidebar({ targetAudience, setTargetAudience, campaignGoal, setCampaignGoal }: SidebarProps) {
  const [fileName, setFileName] = useState<string | null>(null)
  const [goalDropdownOpen, setGoalDropdownOpen] = useState(false)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFileName(file.name)
    }
  }

  return (
    <aside className="w-full lg:w-80 shrink-0">
      <div className="rounded-2xl border border-border/50 bg-card/60 backdrop-blur-xl p-6 space-y-6">
        {/* Upload Brand Guidelines */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <FileText className="h-4 w-4 text-primary" />
            Brand Guidelines
          </div>
          <label
            htmlFor="brand-upload"
            className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-border/50 rounded-xl cursor-pointer hover:border-primary/50 hover:bg-secondary/30 transition-all duration-200"
          >
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <Upload className="h-8 w-8 text-muted-foreground mb-2" />
              {fileName ? (
                <p className="text-sm text-primary font-medium">{fileName}</p>
              ) : (
                <>
                  <p className="text-sm text-muted-foreground">
                    <span className="text-primary font-medium">Click to upload</span> or drag
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">PDF or Text files</p>
                </>
              )}
            </div>
            <input
              id="brand-upload"
              type="file"
              className="hidden"
              accept=".pdf,.txt"
              onChange={handleFileUpload}
            />
          </label>
        </div>

        {/* Target Audience */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Users className="h-4 w-4 text-primary" />
            Target Audience
          </div>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="age" className="text-xs text-muted-foreground">Age Range</Label>
              <Input
                id="age"
                placeholder="e.g., 25-45"
                value={targetAudience.age}
                onChange={(e) => setTargetAudience(prev => ({ ...prev, age: e.target.value }))}
                className="bg-secondary/50 border-border/50 focus:border-primary/50 transition-colors"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="interests" className="text-xs text-muted-foreground">Interests</Label>
              <Input
                id="interests"
                placeholder="e.g., Tech, Fashion"
                value={targetAudience.interests}
                onChange={(e) => setTargetAudience(prev => ({ ...prev, interests: e.target.value }))}
                className="bg-secondary/50 border-border/50 focus:border-primary/50 transition-colors"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="region" className="text-xs text-muted-foreground">Region</Label>
              <Input
                id="region"
                placeholder="e.g., North America"
                value={targetAudience.region}
                onChange={(e) => setTargetAudience(prev => ({ ...prev, region: e.target.value }))}
                className="bg-secondary/50 border-border/50 focus:border-primary/50 transition-colors"
              />
            </div>
          </div>
        </div>

        {/* Campaign Goal */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Target className="h-4 w-4 text-primary" />
            Campaign Goal
          </div>
          <div className="relative">
            <Button
              variant="outline"
              onClick={() => setGoalDropdownOpen(!goalDropdownOpen)}
              className="w-full justify-between bg-secondary/50 border-border/50 hover:border-primary/50 transition-colors"
            >
              {campaignGoal || "Select a goal"}
              <ChevronDown className={cn("h-4 w-4 transition-transform", goalDropdownOpen && "rotate-180")} />
            </Button>
            {goalDropdownOpen && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border/50 rounded-lg shadow-xl z-10 overflow-hidden">
                {campaignGoals.map((goal) => (
                  <button
                    key={goal}
                    onClick={() => {
                      setCampaignGoal(goal)
                      setGoalDropdownOpen(false)
                    }}
                    className={cn(
                      "w-full px-4 py-2.5 text-left text-sm transition-colors",
                      campaignGoal === goal
                        ? "bg-primary/10 text-primary"
                        : "hover:bg-secondary text-foreground"
                    )}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  )
}
