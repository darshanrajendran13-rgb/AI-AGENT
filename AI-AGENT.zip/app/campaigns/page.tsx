"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { 
  Plus, 
  Search, 
  MoreHorizontal, 
  Calendar, 
  Target, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Pause,
  X,
  Instagram,
  Mail,
  Megaphone,
  FileText,
  Eye,
  MousePointer,
  Users,
  Edit3,
  Trash2,
  Play,
  Copy,
  LayoutGrid,
  List
} from "lucide-react"
import { cn } from "@/lib/utils"

type CampaignStatus = "active" | "scheduled" | "paused" | "completed"
type ViewMode = "grid" | "table"

interface Campaign {
  id: string
  name: string
  platform: string
  status: CampaignStatus
  goal: string
  startDate: string
  endDate: string
  performance: number
  impressions: string
  clicks: string
  conversions: string
  budget: string
  spent: string
  description: string
}

const campaigns: Campaign[] = [
  {
    id: "1",
    name: "Summer Sale Launch",
    platform: "Instagram",
    status: "active",
    goal: "Sales",
    startDate: "2026-04-01",
    endDate: "2026-04-30",
    performance: 85,
    impressions: "125.4K",
    clicks: "8.2K",
    conversions: "1.2K",
    budget: "$5,000",
    spent: "$3,850",
    description: "Promoting summer collection with influencer partnerships",
  },
  {
    id: "2",
    name: "Newsletter Growth",
    platform: "Email",
    status: "active",
    goal: "Engagement",
    startDate: "2026-03-15",
    endDate: "2026-05-15",
    performance: 72,
    impressions: "45.8K",
    clicks: "12.1K",
    conversions: "3.4K",
    budget: "$2,500",
    spent: "$1,800",
    description: "Weekly newsletter campaign to boost subscriber engagement",
  },
  {
    id: "3",
    name: "Brand Awareness Q2",
    platform: "Ads",
    status: "scheduled",
    goal: "Awareness",
    startDate: "2026-04-15",
    endDate: "2026-06-30",
    performance: 0,
    impressions: "-",
    clicks: "-",
    conversions: "-",
    budget: "$10,000",
    spent: "$0",
    description: "Multi-channel brand awareness campaign for Q2",
  },
  {
    id: "4",
    name: "Product Tutorial Series",
    platform: "Blog",
    status: "completed",
    goal: "Engagement",
    startDate: "2026-02-01",
    endDate: "2026-03-31",
    performance: 94,
    impressions: "89.2K",
    clicks: "15.6K",
    conversions: "2.8K",
    budget: "$1,500",
    spent: "$1,500",
    description: "Educational content series showcasing product features",
  },
  {
    id: "5",
    name: "Holiday Promo",
    platform: "Instagram",
    status: "paused",
    goal: "Sales",
    startDate: "2026-03-01",
    endDate: "2026-03-15",
    performance: 45,
    impressions: "32.1K",
    clicks: "2.4K",
    conversions: "420",
    budget: "$3,000",
    spent: "$1,350",
    description: "Limited-time holiday promotional campaign",
  },
  {
    id: "6",
    name: "Customer Retention Drive",
    platform: "Email",
    status: "active",
    goal: "Engagement",
    startDate: "2026-04-05",
    endDate: "2026-05-05",
    performance: 68,
    impressions: "28.5K",
    clicks: "6.8K",
    conversions: "890",
    budget: "$1,800",
    spent: "$1,224",
    description: "Re-engagement campaign targeting inactive customers",
  },
]

const statusConfig: Record<CampaignStatus, { icon: React.ComponentType<{ className?: string }>; color: string; bg: string; label: string }> = {
  active: { icon: CheckCircle2, color: "text-emerald-400", bg: "bg-emerald-400/10", label: "Active" },
  scheduled: { icon: Clock, color: "text-blue-400", bg: "bg-blue-400/10", label: "Scheduled" },
  paused: { icon: Pause, color: "text-amber-400", bg: "bg-amber-400/10", label: "Paused" },
  completed: { icon: CheckCircle2, color: "text-muted-foreground", bg: "bg-muted", label: "Completed" },
}

const platformConfig: Record<string, { icon: React.ComponentType<{ className?: string }>; color: string; bg: string }> = {
  Instagram: { icon: Instagram, color: "text-pink-400", bg: "bg-pink-500/20" },
  Email: { icon: Mail, color: "text-blue-400", bg: "bg-blue-500/20" },
  Ads: { icon: Megaphone, color: "text-amber-400", bg: "bg-amber-500/20" },
  Blog: { icon: FileText, color: "text-emerald-400", bg: "bg-emerald-500/20" },
}

export default function CampaignsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState<CampaignStatus | "all">("all")
  const [viewMode, setViewMode] = useState<ViewMode>("grid")
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null)

  const filteredCampaigns = campaigns.filter((campaign) => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = filterStatus === "all" || campaign.status === filterStatus
    return matchesSearch && matchesStatus
  })

  const stats = {
    active: campaigns.filter(c => c.status === "active").length,
    scheduled: campaigns.filter(c => c.status === "scheduled").length,
    paused: campaigns.filter(c => c.status === "paused").length,
    completed: campaigns.filter(c => c.status === "completed").length,
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Background gradient effects */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute top-1/2 -left-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -bottom-40 right-1/3 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold">Campaigns</h1>
            <p className="text-muted-foreground mt-1">Manage and track all your marketing campaigns</p>
          </div>
          <button 
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all duration-200 hover:scale-105"
          >
            <Plus className="h-4 w-4" />
            New Campaign
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { key: "active", icon: CheckCircle2, color: "text-emerald-400", bg: "bg-emerald-400/10", label: "Active" },
            { key: "scheduled", icon: Clock, color: "text-blue-400", bg: "bg-blue-400/10", label: "Scheduled" },
            { key: "paused", icon: AlertCircle, color: "text-amber-400", bg: "bg-amber-400/10", label: "Paused" },
            { key: "completed", icon: TrendingUp, color: "text-muted-foreground", bg: "bg-muted", label: "Completed" },
          ].map((stat) => (
            <button
              key={stat.key}
              onClick={() => setFilterStatus(stat.key as CampaignStatus | "all")}
              className={cn(
                "p-4 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50 text-left transition-all duration-200 hover:scale-[1.02] hover:bg-card/80",
                filterStatus === stat.key && "ring-2 ring-primary"
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn("p-2 rounded-lg", stat.bg)}>
                  <stat.icon className={cn("h-5 w-5", stat.color)} />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats[stat.key as keyof typeof stats]}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Filters & View Toggle */}
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search campaigns..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-secondary/50 border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {(["all", "active", "scheduled", "paused", "completed"] as const).map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all duration-200",
                  filterStatus === status
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary"
                )}
              >
                {status}
              </button>
            ))}
            <div className="flex gap-1 ml-2 p-1 bg-secondary/50 rounded-lg">
              <button
                onClick={() => setViewMode("grid")}
                className={cn(
                  "p-2 rounded-md transition-colors",
                  viewMode === "grid" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <LayoutGrid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setViewMode("table")}
                className={cn(
                  "p-2 rounded-md transition-colors",
                  viewMode === "table" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <List className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Campaign Grid View */}
        {viewMode === "grid" && (
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredCampaigns.map((campaign) => {
              const StatusIcon = statusConfig[campaign.status].icon
              const PlatformIcon = platformConfig[campaign.platform].icon
              return (
                <div
                  key={campaign.id}
                  onClick={() => setSelectedCampaign(campaign)}
                  className="group p-5 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50 hover:bg-card/80 hover:border-border transition-all duration-200 cursor-pointer hover:scale-[1.01]"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={cn("p-2.5 rounded-lg", platformConfig[campaign.platform].bg)}>
                        <PlatformIcon className={cn("h-5 w-5", platformConfig[campaign.platform].color)} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                          {campaign.name}
                        </h3>
                        <p className="text-xs text-muted-foreground">{campaign.platform}</p>
                      </div>
                    </div>
                    <div className={cn("flex items-center gap-1.5 px-2 py-1 rounded-md", statusConfig[campaign.status].bg)}>
                      <StatusIcon className={cn("h-3 w-3", statusConfig[campaign.status].color)} />
                      <span className={cn("text-xs font-medium", statusConfig[campaign.status].color)}>
                        {statusConfig[campaign.status].label}
                      </span>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {campaign.description}
                  </p>

                  {/* Performance Bar */}
                  {campaign.performance > 0 && (
                    <div className="mb-4">
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="text-muted-foreground">Performance</span>
                        <span className="font-medium">{campaign.performance}%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-secondary">
                        <div
                          className={cn(
                            "h-full rounded-full transition-all duration-500",
                            campaign.performance >= 80
                              ? "bg-emerald-400"
                              : campaign.performance >= 50
                              ? "bg-amber-400"
                              : "bg-red-400"
                          )}
                          style={{ width: `${campaign.performance}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Stats Grid */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="text-center p-2 rounded-lg bg-secondary/30">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Eye className="h-3 w-3 text-muted-foreground" />
                      </div>
                      <p className="text-sm font-semibold">{campaign.impressions}</p>
                      <p className="text-[10px] text-muted-foreground">Impressions</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-secondary/30">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <MousePointer className="h-3 w-3 text-muted-foreground" />
                      </div>
                      <p className="text-sm font-semibold">{campaign.clicks}</p>
                      <p className="text-[10px] text-muted-foreground">Clicks</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-secondary/30">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Users className="h-3 w-3 text-muted-foreground" />
                      </div>
                      <p className="text-sm font-semibold">{campaign.conversions}</p>
                      <p className="text-[10px] text-muted-foreground">Conversions</p>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="flex items-center justify-between pt-3 border-t border-border/30">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {new Date(campaign.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })} -{" "}
                      {new Date(campaign.endDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-muted-foreground">{campaign.spent}</span>
                      <span className="text-muted-foreground">/</span>
                      <span className="font-medium">{campaign.budget}</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Campaign Table View */}
        {viewMode === "table" && (
          <div className="rounded-xl bg-card/60 backdrop-blur-sm border border-border/50 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border/50">
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Campaign</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Platform</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Status</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Goal</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Duration</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Performance</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Impressions</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Clicks</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Conversions</th>
                    <th className="text-left p-4 text-sm font-medium text-muted-foreground">Budget</th>
                    <th className="p-4"></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns.map((campaign) => {
                    const StatusIcon = statusConfig[campaign.status].icon
                    const PlatformIcon = platformConfig[campaign.platform].icon
                    return (
                      <tr 
                        key={campaign.id} 
                        className="border-b border-border/30 hover:bg-secondary/30 transition-colors cursor-pointer"
                        onClick={() => setSelectedCampaign(campaign)}
                      >
                        <td className="p-4">
                          <span className="font-medium">{campaign.name}</span>
                        </td>
                        <td className="p-4">
                          <div className={cn("flex items-center gap-2 px-2.5 py-1 rounded-md w-fit", platformConfig[campaign.platform].bg)}>
                            <PlatformIcon className={cn("h-3.5 w-3.5", platformConfig[campaign.platform].color)} />
                            <span className={cn("text-xs font-medium", platformConfig[campaign.platform].color)}>
                              {campaign.platform}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className={cn("flex items-center gap-2 px-2.5 py-1 rounded-md w-fit", statusConfig[campaign.status].bg)}>
                            <StatusIcon className={cn("h-3.5 w-3.5", statusConfig[campaign.status].color)} />
                            <span className={cn("text-xs font-medium capitalize", statusConfig[campaign.status].color)}>
                              {campaign.status}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                            <Target className="h-3.5 w-3.5" />
                            {campaign.goal}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                            <Calendar className="h-3.5 w-3.5" />
                            {new Date(campaign.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })} -{" "}
                            {new Date(campaign.endDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                          </div>
                        </td>
                        <td className="p-4">
                          {campaign.performance > 0 ? (
                            <div className="flex items-center gap-2">
                              <div className="w-16 h-1.5 rounded-full bg-secondary">
                                <div
                                  className={cn(
                                    "h-full rounded-full",
                                    campaign.performance >= 80
                                      ? "bg-emerald-400"
                                      : campaign.performance >= 50
                                      ? "bg-amber-400"
                                      : "bg-red-400"
                                  )}
                                  style={{ width: `${campaign.performance}%` }}
                                />
                              </div>
                              <span className="text-sm">{campaign.performance}%</span>
                            </div>
                          ) : (
                            <span className="text-sm text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="p-4 text-sm">{campaign.impressions}</td>
                        <td className="p-4 text-sm">{campaign.clicks}</td>
                        <td className="p-4 text-sm">{campaign.conversions}</td>
                        <td className="p-4 text-sm">
                          <span className="text-muted-foreground">{campaign.spent}</span>
                          <span className="text-muted-foreground mx-1">/</span>
                          <span>{campaign.budget}</span>
                        </td>
                        <td className="p-4">
                          <button 
                            className="p-2 rounded-lg hover:bg-secondary transition-colors"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Empty State */}
        {filteredCampaigns.length === 0 && (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary/50 mb-4">
              <Megaphone className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No campaigns found</h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery ? "Try adjusting your search or filters" : "Get started by creating your first campaign"}
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
            >
              <Plus className="h-4 w-4" />
              Create Campaign
            </button>
          </div>
        )}
      </main>

      {/* Create Campaign Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-card border border-border rounded-xl shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 className="text-lg font-semibold">Create New Campaign</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 rounded-lg hover:bg-secondary transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Campaign Name</label>
                <input
                  type="text"
                  placeholder="Enter campaign name"
                  className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Platform</label>
                <div className="grid grid-cols-4 gap-2">
                  {Object.entries(platformConfig).map(([platform, config]) => (
                    <button
                      key={platform}
                      className="flex flex-col items-center gap-2 p-3 rounded-lg border border-border hover:border-primary hover:bg-secondary/50 transition-colors"
                    >
                      <config.icon className={cn("h-5 w-5", config.color)} />
                      <span className="text-xs">{platform}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Start Date</label>
                  <input
                    type="date"
                    className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">End Date</label>
                  <input
                    type="date"
                    className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Budget</label>
                <input
                  type="text"
                  placeholder="$0.00"
                  className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <textarea
                  rows={3}
                  placeholder="Describe your campaign goals..."
                  className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 p-6 border-t border-border">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
              >
                Cancel
              </button>
              <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">
                Create Campaign
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Campaign Detail Modal */}
      {selectedCampaign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
          <div className="w-full max-w-2xl bg-card border border-border rounded-xl shadow-2xl animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-border sticky top-0 bg-card z-10">
              <div className="flex items-center gap-3">
                <div className={cn("p-2.5 rounded-lg", platformConfig[selectedCampaign.platform].bg)}>
                  {(() => {
                    const PlatformIcon = platformConfig[selectedCampaign.platform].icon
                    return <PlatformIcon className={cn("h-5 w-5", platformConfig[selectedCampaign.platform].color)} />
                  })()}
                </div>
                <div>
                  <h2 className="text-lg font-semibold">{selectedCampaign.name}</h2>
                  <p className="text-sm text-muted-foreground">{selectedCampaign.platform}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCampaign(null)}
                className="p-2 rounded-lg hover:bg-secondary transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              {/* Status and Goal */}
              <div className="flex items-center gap-3">
                <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-lg", statusConfig[selectedCampaign.status].bg)}>
                  {(() => {
                    const StatusIcon = statusConfig[selectedCampaign.status].icon
                    return <StatusIcon className={cn("h-4 w-4", statusConfig[selectedCampaign.status].color)} />
                  })()}
                  <span className={cn("text-sm font-medium", statusConfig[selectedCampaign.status].color)}>
                    {statusConfig[selectedCampaign.status].label}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Target className="h-4 w-4" />
                  {selectedCampaign.goal}
                </div>
              </div>

              {/* Description */}
              <div>
                <h3 className="text-sm font-medium mb-2">Description</h3>
                <p className="text-muted-foreground">{selectedCampaign.description}</p>
              </div>

              {/* Performance */}
              {selectedCampaign.performance > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium">Performance</h3>
                    <span className="text-lg font-bold">{selectedCampaign.performance}%</span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-secondary">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all",
                        selectedCampaign.performance >= 80
                          ? "bg-emerald-400"
                          : selectedCampaign.performance >= 50
                          ? "bg-amber-400"
                          : "bg-red-400"
                      )}
                      style={{ width: `${selectedCampaign.performance}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Metrics */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-secondary/30 text-center">
                  <Eye className="h-5 w-5 text-muted-foreground mx-auto mb-2" />
                  <p className="text-2xl font-bold">{selectedCampaign.impressions}</p>
                  <p className="text-sm text-muted-foreground">Impressions</p>
                </div>
                <div className="p-4 rounded-xl bg-secondary/30 text-center">
                  <MousePointer className="h-5 w-5 text-muted-foreground mx-auto mb-2" />
                  <p className="text-2xl font-bold">{selectedCampaign.clicks}</p>
                  <p className="text-sm text-muted-foreground">Clicks</p>
                </div>
                <div className="p-4 rounded-xl bg-secondary/30 text-center">
                  <Users className="h-5 w-5 text-muted-foreground mx-auto mb-2" />
                  <p className="text-2xl font-bold">{selectedCampaign.conversions}</p>
                  <p className="text-sm text-muted-foreground">Conversions</p>
                </div>
              </div>

              {/* Budget & Duration */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-secondary/30">
                  <h4 className="text-sm text-muted-foreground mb-1">Budget</h4>
                  <p className="text-lg font-semibold">
                    <span className="text-muted-foreground">{selectedCampaign.spent}</span>
                    <span className="text-muted-foreground mx-2">/</span>
                    {selectedCampaign.budget}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-secondary/30">
                  <h4 className="text-sm text-muted-foreground mb-1">Duration</h4>
                  <p className="text-lg font-semibold flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    {new Date(selectedCampaign.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })} -{" "}
                    {new Date(selectedCampaign.endDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between p-6 border-t border-border">
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                  <Copy className="h-4 w-4" />
                  Duplicate
                </button>
                <button className="flex items-center gap-2 px-3 py-2 rounded-lg text-destructive hover:bg-destructive/10 transition-colors">
                  <Trash2 className="h-4 w-4" />
                  Delete
                </button>
              </div>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border hover:bg-secondary transition-colors">
                  <Edit3 className="h-4 w-4" />
                  Edit
                </button>
                {selectedCampaign.status === "paused" && (
                  <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">
                    <Play className="h-4 w-4" />
                    Resume
                  </button>
                )}
                {selectedCampaign.status === "active" && (
                  <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg font-medium hover:bg-amber-500/90 transition-colors">
                    <Pause className="h-4 w-4" />
                    Pause
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
