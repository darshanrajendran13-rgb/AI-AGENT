"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { TrendingUp, TrendingDown, Users, Eye, MousePointer, DollarSign, ArrowUpRight, Instagram, Mail, Megaphone, FileText } from "lucide-react"
import { cn } from "@/lib/utils"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts"

const performanceData = [
  { name: "Jan", impressions: 45000, clicks: 3200, conversions: 420 },
  { name: "Feb", impressions: 52000, clicks: 3800, conversions: 510 },
  { name: "Mar", impressions: 61000, clicks: 4500, conversions: 620 },
  { name: "Apr", impressions: 78000, clicks: 5200, conversions: 780 },
  { name: "May", impressions: 85000, clicks: 6100, conversions: 890 },
  { name: "Jun", impressions: 92000, clicks: 6800, conversions: 980 },
]

const platformData = [
  { name: "Instagram", value: 42, color: "#ec4899" },
  { name: "Email", value: 28, color: "#3b82f6" },
  { name: "Ads", value: 18, color: "#f59e0b" },
  { name: "Blog", value: 12, color: "#10b981" },
]

const engagementData = [
  { name: "Mon", engagement: 4200 },
  { name: "Tue", engagement: 3800 },
  { name: "Wed", engagement: 5100 },
  { name: "Thu", engagement: 4600 },
  { name: "Fri", engagement: 5800 },
  { name: "Sat", engagement: 6200 },
  { name: "Sun", engagement: 5400 },
]

const topCampaigns = [
  { name: "Summer Sale Launch", platform: "Instagram", roi: 324, trend: "up" },
  { name: "Newsletter Growth", platform: "Email", roi: 218, trend: "up" },
  { name: "Product Tutorial Series", platform: "Blog", roi: 186, trend: "down" },
  { name: "Holiday Promo", platform: "Ads", roi: 142, trend: "up" },
]

const platformIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Instagram: Instagram,
  Email: Mail,
  Ads: Megaphone,
  Blog: FileText,
}

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState<"7d" | "30d" | "90d" | "1y">("30d")

  return (
    <div className="min-h-screen bg-background">
      {/* Background gradient effects */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute top-1/2 -left-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -bottom-40 right-1/3 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold">Analytics</h1>
            <p className="text-muted-foreground mt-1">Track your marketing performance and insights</p>
          </div>
          <div className="flex gap-2">
            {(["7d", "30d", "90d", "1y"] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                  timeRange === range
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary"
                )}
              >
                {range === "7d" ? "7 Days" : range === "30d" ? "30 Days" : range === "90d" ? "90 Days" : "1 Year"}
              </button>
            ))}
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="p-5 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Impressions</p>
                <p className="text-2xl font-bold mt-1">413K</p>
                <div className="flex items-center gap-1 mt-2">
                  <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-xs text-emerald-400">+12.5%</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-primary/10">
                <Eye className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
          <div className="p-5 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Clicks</p>
                <p className="text-2xl font-bold mt-1">29.6K</p>
                <div className="flex items-center gap-1 mt-2">
                  <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-xs text-emerald-400">+8.2%</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-blue-500/10">
                <MousePointer className="h-5 w-5 text-blue-400" />
              </div>
            </div>
          </div>
          <div className="p-5 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Conversions</p>
                <p className="text-2xl font-bold mt-1">4.2K</p>
                <div className="flex items-center gap-1 mt-2">
                  <TrendingDown className="h-3.5 w-3.5 text-red-400" />
                  <span className="text-xs text-red-400">-2.4%</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-emerald-500/10">
                <Users className="h-5 w-5 text-emerald-400" />
              </div>
            </div>
          </div>
          <div className="p-5 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue</p>
                <p className="text-2xl font-bold mt-1">$48.2K</p>
                <div className="flex items-center gap-1 mt-2">
                  <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-xs text-emerald-400">+18.7%</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-amber-500/10">
                <DollarSign className="h-5 w-5 text-amber-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Performance Over Time */}
          <div className="lg:col-span-2 p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <h3 className="text-lg font-semibold mb-6">Performance Over Time</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceData}>
                  <defs>
                    <linearGradient id="impressionsGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.65 0.2 160)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.65 0.2 160)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.01 260 / 0.5)" />
                  <XAxis dataKey="name" stroke="oklch(0.65 0 0)" fontSize={12} />
                  <YAxis stroke="oklch(0.65 0 0)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.12 0.01 260)",
                      border: "1px solid oklch(0.25 0.01 260 / 0.5)",
                      borderRadius: "8px",
                      color: "oklch(0.98 0 0)",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="impressions"
                    stroke="oklch(0.65 0.2 160)"
                    strokeWidth={2}
                    fill="url(#impressionsGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Platform Distribution */}
          <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <h3 className="text-lg font-semibold mb-6">Platform Distribution</h3>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={platformData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {platformData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.12 0.01 260)",
                      border: "1px solid oklch(0.25 0.01 260 / 0.5)",
                      borderRadius: "8px",
                      color: "oklch(0.98 0 0)",
                    }}
                    formatter={(value: number) => [`${value}%`, "Share"]}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {platformData.map((platform) => (
                <div key={platform.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: platform.color }} />
                  <span className="text-sm text-muted-foreground">{platform.name}</span>
                  <span className="text-sm font-medium ml-auto">{platform.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Weekly Engagement */}
          <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <h3 className="text-lg font-semibold mb-6">Weekly Engagement</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={engagementData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.01 260 / 0.5)" />
                  <XAxis dataKey="name" stroke="oklch(0.65 0 0)" fontSize={12} />
                  <YAxis stroke="oklch(0.65 0 0)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.12 0.01 260)",
                      border: "1px solid oklch(0.25 0.01 260 / 0.5)",
                      borderRadius: "8px",
                      color: "oklch(0.98 0 0)",
                    }}
                  />
                  <Bar dataKey="engagement" fill="oklch(0.65 0.2 160)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top Performing Campaigns */}
          <div className="p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border/50">
            <h3 className="text-lg font-semibold mb-6">Top Performing Campaigns</h3>
            <div className="space-y-4">
              {topCampaigns.map((campaign, index) => {
                const PlatformIcon = platformIcons[campaign.platform]
                return (
                  <div
                    key={campaign.name}
                    className="flex items-center gap-4 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary text-sm font-medium">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{campaign.name}</p>
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <PlatformIcon className="h-3.5 w-3.5" />
                        {campaign.platform}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1">
                        <span className="font-semibold">{campaign.roi}%</span>
                        <span className="text-sm text-muted-foreground">ROI</span>
                      </div>
                      <div className={cn(
                        "flex items-center gap-0.5 text-xs",
                        campaign.trend === "up" ? "text-emerald-400" : "text-red-400"
                      )}>
                        {campaign.trend === "up" ? (
                          <ArrowUpRight className="h-3 w-3" />
                        ) : (
                          <TrendingDown className="h-3 w-3" />
                        )}
                        {campaign.trend === "up" ? "Trending up" : "Trending down"}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
